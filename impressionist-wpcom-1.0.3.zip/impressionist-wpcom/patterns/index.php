<?php declare( strict_types = 1 ); ?>
<?php
/**
 * Title: index
 * Slug: impressionist/index
 * Categories: hidden
 * Inserter: no
 */
?>
<!-- wp:template-part {"slug":"header","tagName":"header"} /-->

<!-- wp:query {"queryId":9,"query":{"perPage":"20","pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false},"tagName":"main"} -->
<main class="wp-block-query"><!-- wp:post-template {"style":{"spacing":{"blockGap":"0"}}} -->
<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|70"},"padding":{"bottom":"var:preset|spacing|80"}}}} -->
<div class="wp-block-columns" style="padding-bottom:var(--wp--preset--spacing--80)"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:post-featured-image {"isLink":true,"align":"wide"} /--></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"bottom","style":{"spacing":{"padding":{"right":"6vw","left":"6vw","top":"3vh","bottom":"3vh"}}}} -->
<div class="wp-block-column is-vertically-aligned-bottom" style="padding-top:3vh;padding-right:6vw;padding-bottom:3vh;padding-left:6vw"><!-- wp:post-title {"isLink":true,"style":{"elements":{"link":{"color":{"text":"var:preset|color|contrast"}}},"typography":{"lineHeight":"1.4"}},"textColor":"contrast"} /-->

<!-- wp:read-more {"content":"Read More"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
<!-- /wp:post-template -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"right":"4vw","left":"4vw"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-right:4vw;padding-left:4vw"><!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"4vw","right":"4vw"}},"border":{"top":{"color":"var:preset|color|tertiary","width":"1px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="border-top-color:var(--wp--preset--color--tertiary);border-top-width:1px;padding-top:var(--wp--preset--spacing--50);padding-right:4vw;padding-bottom:var(--wp--preset--spacing--50);padding-left:4vw"><!-- wp:query-pagination {"layout":{"type":"flex","justifyContent":"space-between"}} -->
<!-- wp:query-pagination-previous /-->

<!-- wp:query-pagination-numbers /-->

<!-- wp:query-pagination-next /-->
<!-- /wp:query-pagination --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:query-no-results -->
<!-- wp:group {"style":{"spacing":{"padding":{"right":"4vw","left":"4vw"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group" style="padding-right:4vw;padding-left:4vw"><!-- wp:paragraph -->
<p><?php esc_html_e('Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'impressionist');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- /wp:query-no-results --></main>
<!-- /wp:query -->

<!-- wp:template-part {"slug":"footer","tagName":"footer"} /-->